document.location.href = 'https://chupcko.org/start/';
