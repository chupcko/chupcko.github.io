document.location.href = 'http://chupcko.org/start/';
